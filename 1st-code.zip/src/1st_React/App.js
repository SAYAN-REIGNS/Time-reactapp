import "./styles.css";
import React from "react";
import Heading from "./heading";

export default function App() {
  return (
    <div className="App">
     <Heading />
    </div>
  );
}
